// sup dudue
console.log("search found")
console.log("bark bark");

document.getElementById("searchFinal").innerHTML=localStorage.getItem("textvalue");