//Bark bark
//DogDoggieDo_SearchEngine🐶 

console.log("Bark bark")
console.log("DogDoggieDo_SearchEngine🐶")